CREATE TABLE delivery_shipping (
    id INT PRIMARY KEY AUTO_INCREMENT,
    orderId INT,
    delivery_date DATE,
    status VARCHAR(50),
    courier_name VARCHAR(50),
    tracking_no VARCHAR(50),
    username VARCHAR(50))