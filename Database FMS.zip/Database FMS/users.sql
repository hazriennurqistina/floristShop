create table users (
username varchar(30) primary key,
f_name varchar(30),
l_name varchar(30),
no_phone varchar(30),
address varchar(30),
state varchar(30),
email varchar (30),
password varchar (10))