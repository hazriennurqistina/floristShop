/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller.com;

import dao.com.UserDao;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import fms.com.User;
import java.sql.SQLException;
import javax.servlet.http.HttpSession;

/**
 *
 * @author TOSHIBA
 */
//@WebServlet("/UpdateProfileServlet")
public class UpdateProfileServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("currentUser");//

        if (user == null) {
            response.sendRedirect("login.jsp?error=Please+login+to+update+profile");
            return;
        }

        String firstName = request.getParameter("f_name");
        String lastName = request.getParameter("l_name");
        String phoneNo = request.getParameter("no_phone");
        String address = request.getParameter("address");
        String state = request.getParameter("state");
        String email = request.getParameter("email");

        user.setFirstName(firstName);
        user.setLastName(lastName);
        user.setPhoneNo(phoneNo);
        user.setAddress(address);
        user.setState(state);
        user.setEmail(email);

        int rowsAffected = UserDao.updateUserProfile(user); // Log the error and handle exception appropriately
        if (rowsAffected > 0) {
            //HttpSession session = request.getSession();
            session.setAttribute("updateSuccess", "Profile updated successfully!");
            response.sendRedirect("profile.jsp"); // Redirect to profile page
        } else {
            // No rows affected, handle update failure
            response.sendRedirect("updateProfile.jsp?error=Profile+update+failed");
        }
    }
}

// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
/**
 * Handles the HTTP <code>GET</code> method.
 *
 * @param request servlet request
 * @param response servlet response
 * @throws ServletException if a servlet-specific error occurs
 * @throws IOException if an I/O error occurs
 */
/**
 * Handles the HTTP <code>POST</code> method.
 *
 * @param request servlet request
 * @param response servlet response
 * @throws ServletException if a servlet-specific error occurs
 * @throws IOException if an I/O error occurs
 */
