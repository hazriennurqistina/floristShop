/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AddSaleServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String flowerName = request.getParameter("flowerName");
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        double price = Double.parseDouble(request.getParameter("price"));
        String saleDate = request.getParameter("saleDate");

        // Create a database connection
        String url = "jdbc:mysql://localhost:3306/floristms";
        String user = "root";
        String password = "admin";

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(url, user, password);
            // Create a prepared statement
            stmt = conn.prepareStatement("INSERT INTO sales (flower_name, quantity, price, sale_date) VALUES (?, ?, ?, ?)");
            // Set the parameters
            stmt.setString(1, flowerName);
            stmt.setInt(2, quantity);
            stmt.setDouble(3, price);
            stmt.setString(4, saleDate);
            // Execute the query
            stmt.executeUpdate();
        } catch (ClassNotFoundException e) {
            System.out.println("Error loading MySQL driver: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Error connecting to database: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(AddSaleServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        // Redirect to the sales.jsp page
        response.sendRedirect("sales.jsp");
    }
}