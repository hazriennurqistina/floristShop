/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao.com;

import java.sql.*;
import fms.com.User;

/**
 *
 * @author TOSHIBA
 */
public class UserDao {

    public static Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/floristms", "root", "admin");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
        }
        return con;
    }

    public static int registerUser(User myUser) {
        int result = 0;
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO users(username, f_name, l_name, no_phone, address, state, email, password) VALUES(?,?,?,?,?,?,?,?)");
            ps.setString(1, myUser.getUserName());
            ps.setString(2, myUser.getFirstName());
            ps.setString(3, myUser.getLastName());
            ps.setString(4, myUser.getPhoneNo());
            ps.setString(5, myUser.getAddress());
            ps.setString(6, myUser.getState());
            ps.setString(7, myUser.getEmail());
            ps.setString(8, myUser.getPassword());

            result = ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e);
        }
        return result;
    }

    public static int updateUserProfile(User myUser) {
        int result = 0;
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(
                    "update users set f_name=?, l_name=?,no_phone=?, address=?, state=?, email=?, password=? where username=?");
            ps.setString(1, myUser.getFirstName());
            ps.setString(2, myUser.getLastName());
            ps.setString(3, myUser.getPhoneNo());
            ps.setString(4, myUser.getAddress());
            ps.setString(5, myUser.getState());
            ps.setString(6, myUser.getEmail());
            ps.setString(7, myUser.getPassword());
            ps.setString(8, myUser.getUserName());
            result = ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
        }
        return result;
    }

    public static User getUserByUsername(String username) {
        User myUser = null;
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("select * from users where username=?");
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                myUser = new User();

                myUser.setUserName(rs.getString("username"));
                myUser.setFirstName(rs.getString("f_name"));
                myUser.setLastName(rs.getString("l_name"));
                myUser.setPhoneNo(rs.getString("no_phone"));
                myUser.setAddress(rs.getString("address"));
                myUser.setState(rs.getString("state"));
                myUser.setEmail(rs.getString("email"));
                myUser.setPassword(rs.getString("password"));
                
                
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return myUser;
    }
}
