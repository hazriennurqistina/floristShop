/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.model;

/**
 *
 * @author Huawei
 */
public class DeliveryShipping {
    
    public DeliveryShipping() {}
    
    private int id;
    private String orderId;
    private String deliveryDate;
    private String status;
    private String courierName;
    private String trackingNo;
    private String username;

   

    public DeliveryShipping(int id, String orderId, String deliveryDate, String status, String courierName, String trackingNo, String username) {
        this.id = id;
        this.orderId = orderId;
        this.deliveryDate = deliveryDate;
        this.status = status;
        this.courierName = courierName;
        this.trackingNo = trackingNo;
        this.username = username;
    }

    // Getters and Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCourierName() {
        return courierName;
    }

    public void setCourierName(String courierName) {
        this.courierName = courierName;
    }

    public String getTrackingNo() {
        return trackingNo;
    }

    public void setTrackingNo(String trackingNo) {
        this.trackingNo = trackingNo;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
