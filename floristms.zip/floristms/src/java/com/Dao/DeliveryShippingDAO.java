/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dao;

import com.model.DeliveryShipping;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DeliveryShippingDAO {
    private String URL = "jdbc:mysql://localhost:3306/floristms";
    private String Username = "root";
    private String Password = "admin";

    private static  String INSERT_DELIVERY_SQL = "INSERT INTO delivery_shipping (order_id, delivery_date, status, courier_name, tracking_no, username) VALUES (?, ?, ?, ?, ?, ?)";
    private static  String SELECT_ALL_DELIVERY = "SELECT * FROM delivery_shipping";

    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(URL, Username, Password);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return connection;
    }

    public void addDeliveryShipping(DeliveryShipping delivery) {
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_DELIVERY_SQL)) {
            preparedStatement.setString(1, delivery.getOrderId());
            preparedStatement.setString(2, delivery.getDeliveryDate());
            preparedStatement.setString(3, delivery.getStatus());
            preparedStatement.setString(4, delivery.getCourierName());
            preparedStatement.setString(5, delivery.getTrackingNo());
            preparedStatement.setString(6, delivery.getUsername());
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<DeliveryShipping> getAllDeliveryShippings() {
        List<DeliveryShipping> deliveries = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_DELIVERY)) {
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String orderId = rs.getString("order_id");
                String deliveryDate = rs.getString("delivery_date");
                String status = rs.getString("status");
                String courierName = rs.getString("courier_name");
                String trackingNo = rs.getString("tracking_no");
                String username = rs.getString("username");
                DeliveryShipping delivery = new DeliveryShipping(id, orderId, deliveryDate, status, courierName, trackingNo, username);
                deliveries.add(delivery);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return deliveries;
    }
}