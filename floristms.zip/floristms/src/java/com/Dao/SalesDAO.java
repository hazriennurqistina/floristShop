/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Dao;

import com.model.Sale;

import java.sql.*;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SalesDAO {

    private String jdbcURL = "jdbc:mysql://localhost:3306/floristms";
    private String jdbcusername = "root";
    private String jdbcpassword = "admin";

    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcusername, jdbcpassword);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return connection;
    }

    public void insertSale(Sale sale) {
        System.out.println("Preparing to insert sale: " + sale);
        try ( Connection connection = getConnection();  
            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO sales (flower_name, quantity, price, sale_date) VALUES (?, ?, ?, ?)")) {
            double totalprice = (sale.getPrice() * sale.getQuantity());
            preparedStatement.setString(1, sale.getFlowerName());
            preparedStatement.setInt(2, sale.getQuantity());
            preparedStatement.setDouble(3, sale.getPrice());
            preparedStatement.setDate(4, sale.getSaleDate());
            
            System.out.println("Inserting sale with values: " + sale.toString() + ", totalprice: " + totalprice);
            System.out.println("Executing insert...");
            int result = preparedStatement.executeUpdate();
            System.out.println("Insert executed successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
     private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
     }
     

    public List<Sale> selectAllSales() {
    List<Sale> sales = new ArrayList<>();
    try (Connection connection = getConnection();  
         PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM sales")) {
        ResultSet rs = preparedStatement.executeQuery();
        while (rs.next()) {
            int id = rs.getInt("id");
            String flowerName = rs.getString("flower_name");
            int quantity = rs.getInt("quantity");
            double price = rs.getDouble("price");
            Date saleDate = rs.getDate("sale_date");
            sales.add(new Sale(id, flowerName, quantity, price, saleDate));
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return sales;
}
}