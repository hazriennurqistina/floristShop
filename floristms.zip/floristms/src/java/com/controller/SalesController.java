/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.controller;

import com.Dao.SalesDAO;
import com.model.Sale;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;

@WebServlet("/sales")
public class SalesController extends HttpServlet {

    private SalesDAO salesDAO;

    public void init() {
        salesDAO = new SalesDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Sale> sales = salesDAO.selectAllSales();
        request.setAttribute("sales", sales);

        double totalIncome = 0;
        for (Sale sale : sales) {
            totalIncome += sale.getPrice() * sale.getQuantity();
        }
        request.setAttribute("totalIncome", totalIncome);

        RequestDispatcher dispatcher = request.getRequestDispatcher("SaleForm.jsp");
        dispatcher.forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String flowerName = request.getParameter("flowerName");
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        double price = Double.parseDouble(request.getParameter("price"));
        Date saleDate = Date.valueOf(request.getParameter("saleDate"));

        Sale newSale = new Sale(0, flowerName, quantity, price, saleDate);

        salesDAO.insertSale(newSale);

        List<Sale> sales = salesDAO.selectAllSales();
        request.setAttribute("sales", sales);

        double totalIncome = 0;
        for (Sale sale : sales) {
            totalIncome += sale.getPrice() * sale.getQuantity();
        }
        request.setAttribute("totalIncome", totalIncome);

        RequestDispatcher dispatcher = request.getRequestDispatcher("SaleForm.jsp");
        dispatcher.forward(request, response);
    }
}
